Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> import socket
>>> HOST = "127.0.0.1"
>>> PORT = 65432
>>> def start_client():
...     with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
...         client_socket.connect((HOST, PORT))
...         print(f"Connected to server at {HOST}:{PORT}")
...         item_name = input("Enter the name of the item you need " "(e.g. vaccine stock, fertiliser, water testing kit, animal feed): ")
...         client_socket.sendall(item_name.encode("utf-8"))
...         response = client_socket.recv(1024).decode("utf-8")
...         print(f"Server response: {response}")
...     if _name_ == "_main_":
...         start_client()
