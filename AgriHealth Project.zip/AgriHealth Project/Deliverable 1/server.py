Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import socket
HOST = "127.0.0.1"
PORT = 65432
Available_Items = ["vaccine stock", "fertiliser", "water testing kits", "animal feed"]
def start_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((HOST, PORT))
        server_socket.listen(1)
        print(f"Agrihealth Rural Operations Server")
        print(f"Server started. Waiting for a client connection on {HOST}:{PORT}...")
        while True:
...             conn, addr = server_socket.accept()
...             with conn:
...                 print(f"Connected by {addr}")
...                 data = conn.recv(1024)
...                 if not data:
...                     continue
...                 requested_item = data.decode("utf-8").strip().lower()
...                 print(f"Client requested: '{requested_items}'")
...                 if requested_item in Available_Items:
...                     response = f"Available: '{requested_item}' is in stock."
...                 else;
...                 
SyntaxError: expected ':'
>>> def start_server():
...     with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
...         server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
...         server_socket.bind((HOST, PORT))
...         server_socket.listen(1)
...         print(f"Agrihealth Rural Operations Server")
...         print(f"Server started. Waiting for a client connection on {HOST}:{PORT}...")
...         while True:
...             conn, addr = server_socket.accept()
...             with conn:
...                 print(f"Connected by {addr}")
...                 data = conn.recv(1024)
...                 if not data:
...                     continue
...                 requested_item = data.decode("utf-8").strip().lower()
...                 print(f"Client requested: '{requested_items}'")
...                 if requested_item in Available_Items:
...                     response = f"Available: '{requested_item}' is in stock."
...                 else:
...                     response = f"Not Available: '{requested_item}' is not in stock."
...                 conn.sendall(response.encoded("utf-8"))
...                 print(f"Sent response: {response}")
...             if _name_ == "_main_":
...                 start_server()
... 
...                 
>>> 
