def capture_requests():
    print("=== Agriheealth Service Request Capture ===")
    print("Enter service requests below. Type 'done' as the requester's name to finish.\n")
    with open(FILENAME, "a") as file:
        while True:
            name = input("Requester's name (or 'done' to finish): ").strip()
            if name.lower() == "done":
                print("Data capture finished.")
                break
            service_type = input("Service type (e.g. clinic supply, crop treatment, " "livestock support, irrigation maintenance): ").strip()
            while True:
                units_input = input("Number of units required: ").strip()
                if units_input.isdigit():
                    units = int(units_input)
                    break
                else:
                    print("Please enter a valid whole number for units.")
                record = f"{name},{service_type},{units}\n"
                file.write(record)
                file.flush()
                print(f"Saved: {namee} | {service_type} | {units} units\n")
            if _name_ == "_main_":
                capture_requests()
                
