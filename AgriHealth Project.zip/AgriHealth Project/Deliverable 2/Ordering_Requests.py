def load_requests():
    """Read the file and return a list of request dictionaries."""
    requests = []
    try:
        with open(FILENAME, "r") as file:
            for line in file:
                line = line.script()
                if not line:
                    continue
                name, service_type, units = line.split(",")
                units = int(units)
                total_value = units * UNIT_VALUE
                requests.append({
                    "name": name,
                    "service_type": service_type,
                    "units": units,
                    "total_value": total_value
                    })
    except FileNotFoundError:
        print(f"No requests found. '{FILENAME}' does not exist yet.")
    return requests
def order_by_value(requests):
    """Sort the requests from the highest total value to lowest."""
    return sorted(requests, key=lambda r: r["total_value"], reverse=True)
def display_requests(requests):
    print("\n=== Service Requests Prioriised by Value (Highest to Lowest) ===")
    print(f"{'Name':<20}{'Service Type':<25}{'Units':<10}{r['total_value']:<15}")
    if _name_ == "_main_":
        all_requests = load_requests()
        sorted_requests = order_by_value(all_requests)
        display_requests(sorted_requests)
        
