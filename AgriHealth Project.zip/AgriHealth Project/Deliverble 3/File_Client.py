import socket
import os
HOST = "127.0.0.1"
PORT = 65434
BUFFER_SIZE = 4096
def recv_line(sock):
    """ Reads one byte at a time until a newline is found, so a header message is never accidentally mixed with the raw file bytes that follow it."""
    data = b ""
    while not data.endswith(b"\n"):
        chunk = sock.recv(1)
        if not chunk:
            break
        data += chunk
    return data.decode("utf-8").strip()


def upload_files(filepath):
    if not os.path.isfile(filepath):
        print(f"FAILURE: '{filepath}' does not exist on this computer.")
        return
    filename = os.path.basename(filepath)
    filesize = os.path.getsize(filepath)
    with socket.create_connection((HOST, PORT)) as sock:
        sock.sendall(f"UPLOAD|{filename}|{filesize}\n".encode("utf-8"))
        with open(filepath, "rb") as f:
            while chunk := f.read(BUFFER_SIZE):
                sock.sendall(chunk)
        response = recv_line(sock)
        print(f"Server response: {response}")


def download_file(filename, save_as=None):
    save_as = save_as or f"download_{filename}"
    with socket.create_connection((HOST, PORT)) as sock:
        sock.sendall(f"DOWNLOAD|{filename}\n".encode("utf-8"))
        header = recv_line(sock)
        parts = header.split("|")
        if parts[0] == "OK":
            filesize = int(parts[1])
            received = 0
            with open(save_as, "wb") as f:
                while received <filesize:
                    chunk = sock.recv(min(BUFFER_SIZE, filesize - received))
                    if not chunk:
                        break
                    f.write(chunk)
                    received += len(chunk)
            print(f"Downloaded '{filename}' -> saved as '{save_as}' ({received} bytes)")
        else:
            print(f"Server response: {header}")


def main():
    print("=== Agrihealth File Exchange Client ===")
    print("1. Upload a file")
    print("2. Download a file")
    choice = input("Choose an option (1 or 2): ").strip()
    if choice == "1":
        filepath = input("Enter the path of the file to upload: ").strip()
        upload_file(filepath)
    elif choice == "2":
        filename = input("Enter the name of the file to download: ").strip()
        download_file(filename)
    else:
        print("Invalid choice.")
if _name_ == "_main_":
    main()
