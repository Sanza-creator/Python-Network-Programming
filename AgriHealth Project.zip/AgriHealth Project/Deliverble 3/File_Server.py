import socket
import threading
import os
HOST = "127.0.0.1"
PORT = 65434
STORAGE_FOLDER = "server_files"
BUFFER_SIZE = 4096
os.makedirs(STORAGE_FOLDER, exist_ok=True)
def handle_client(conn, addr):
    """Handles a single client's request in its own thread."""
    print(f"[FILE SERVER] Connected by {addr}")
    try:
        header = conn.recv(BUFFER_SIZE).decode("utf-8")
        parts = header.split("|")
        command = parts[0].upper()
        if command == "UPLOAD":
            filename = parts[1]
            filesize = int(parts[2])
            filepath = os.path.join(STORAGE_FOLDER, os.path.basename(filename))
            recieved = 0
            with open(filepath, "wb") as f:
                while recieved <filesize:
                    chunk = conn.recv(min(BUFFER_SIZE, filesize - received))
                    if not chunk:
                        break
                    f.write(chunk)
                    received += len(chunk)
            print(f"[FILE SERVER] Recieved '{filename}' ({received} bytes) from {addr}")
            conn.sendall(f"OK| {filename} uploaded successfully".encode("utf-8"))
        elif command == "DOWNLOAD":
            filename = parts[1]
            filepath = os.path.join(STORAGE_FOLDER os.path.basename(filename))
            if os.path.isfile(filepath):
                filesize = os.path.getsize(filepath)
                conn.sendall(f"OK|{filesize}".encode("utf-8"))
                with open(filepath), "rb") as f:
                    while chunk := f.read(BUFFER_SIZE):
                        conn.sendall(chunk)
                print(f"[FILE SERVER] Sent '{filename}' ({filesize} bytes) to {addr}")
            else:
                conn.sendall(b"ERROR|Unknown command")
        except Exception as e:
            print(f"[FILE SERVER] Error handling {addr}: {e}")
        finally:
            conn.close()
            print(f"[FILE_SERVER] Connection with {addr} closed")


def start_file_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((HOST, PORT))
        server_socket.listen(1)
        print(f"[FILE SERVER] Started. Waiting for the client connections on {HOST}:{PORT}...")
        while True:
            conn, addr = server_socket.accept()
            client_thread = threading.Thread(targert=handle_client, args=(conn, addr), daemon=True)
            client_thread.start()
    if _name_ == "_main_":
        start_file_server()
        
