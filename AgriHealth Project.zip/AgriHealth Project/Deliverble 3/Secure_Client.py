import socket
import ssl
HOST = "127.0.0.1"
PORT = 65433
CERT_FILE = "server.crt"
def start_secure_client():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    try:
        context.load_verify_locations(CERT_FILE)
    except FileNotFoundError:
        print(f"FAILURE: Could not find '{CERT_FILE}'."
              f"Copy the server's certificate into this folder first.")
        return
    context.check_hostname = False
    try:
        with socket.create_connection((HOST, PORT), timeout=5) as sock:
            print(f"[SECURE CLIENT] Secure connection established with"
                  f"{HOST}:{PORT} (cipher: {secure_sock.cipher()[0]})")
            record_name = input(
                "Enter the record you need "
                "(e.g. patient referral files, livestock disease reports, "
                "medicine delivery forms, irrigation maintenance documents):"
            )
            secure_sock.sendall(record_name.encode("utf-8"))
            response = secure_sock.recv(1024).decode("utf-8")
            print(f"[SECURE CLIENT] Server response: {response}")
        except ConnectionRefusedError:
            print(f"FAILURE: Could not connect. Is secure_server.py running on{HOST}:{PORT}?")
        except ssl.SSLError as e:
            print(f"FAILURE: Secure connection could not be established: {e}")
        except socket.timeout:
            print("FAILURE: Connection timed out.")
        if _name_ == "_main_":
            start_secure_client()
            
