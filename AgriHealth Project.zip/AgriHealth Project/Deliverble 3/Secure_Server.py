import socket
import ssl
HOST = "127.0.0.1"
PORT = 65433
CERT_FILE = "server.crt"
KEY_FILE = "server.key"
SENSITIVE_RECORDS = {
    "patient referral files": "Referral: J. Dlamini -> Rural Clinic 4, priority: high.",
    "livestock disease reports:": "Report: Foot-and-mouth suspected, Farm 12, awaiting lab result.",
    "Medicine delivery forms": "Delivery: 50 units antibiotics -> Clinic 4, ETA 2 days.",
    "irrigation maintenance documents": "Maintenance: Pump station 3 requires valve replacement."
}
def start_secure_server():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    try:
        context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
    except FileNotFoundError:
        print(f"FAILURE: Could not find '{CERT_FILE}' or '{KEY_FILE}'.")
        print("Run the OpenSSL command in 3.2_certificate_setup.txt first.")
        return
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((HOST, PORT))
        sock.listen(1)
        print(f"[SECURE SERVER] Waiting for a secure client connection on {HOST}:{PORT}...")
        with context.wrap_socket(sock,server_side=True) as secure_sock:
            while True:
                try:
                    conn, addr = secure_sock.accept()
                except ssl.SSLError as e:
                    print(f"FAILURE: Secure connection could not be established: {e}")
                    continue
                with conn:
                    print(f"[SECURE SERVER] Secure connection established with {addr}")
                    data = conn.recv(1024)
                    if not data:
                        continue
                    requested_record = data.decode("utf-8").strip().lower()
                    print(f"[SECURE SERVER] Client securely requested: '{requested_record}'")
                    if requested_record in SENSITIVE_RECORDS:
                        response = f"AUTHORISED: {SENSITIVE_RECORDS[requested_record]}"
                    else:
                        response = f"NOT FOUND: '{requested_record}' is not a recognised record."
                    conn.sendall(response.encode("utf-8"))
                    print(f"[SECURE SERVER] Sent encrypted response.")
                if _name_ == "_main_":
                    start_secure_server()
                    
                    
